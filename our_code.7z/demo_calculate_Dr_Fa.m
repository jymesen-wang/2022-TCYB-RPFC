clc;clear all;close all;
CurrentFolder = pwd;
addpath('Funcs');

%dilate core
se=strel('square',3);
IoU_threshold = 0.7;

DATASET = {'\Aircrafts','\Airplanes','\Drones'};
result_name = {'*.jpg','*.bmp','*.jpg'};
gt_name = {'*.jpg','*.jpg','*.jpg'};
Dr_store=[];
Fa_store=[];

for i =1:3

    RESULT = [CurrentFolder DATASET{i} '\out\'];
    GT = [CurrentFolder DATASET{i} '\GT\'];
    startframe=[3;10;10];
    endframe=[50;150;350];
    
    Dr=0;
    Fa=0;

    dir_result = dir([RESULT result_name{i}]);
    dir_gt = dir([GT gt_name{i}]);
    for j = startframe(i) : endframe(i)
        gt_name = dir_gt(j).name;
        gt_pic = (imread([GT gt_name]));
        if size(gt_pic,3) == 3
            gt_pic = rgb2gray(gt_pic);
        end
        result_name = dir_result(j).name;
        result_pic = imread([RESULT result_name]);
        if size(result_pic,3) == 3
            result_pic = rgb2gray(result_pic);
        end

        gt_pic = im2double(gt_pic);
        tmp = 0.5*max(gt_pic(:));
        gt_pic(gt_pic<tmp) = 0;
        gt_pic(gt_pic>=tmp) = 1;
        gt_pic = logical(gt_pic);
        % dilating
        gt_pic = imdilate(gt_pic,se);
        
        % the threshold depends on the formats of results.
        % wether the result is gray format or binary format.
        result_threshold = 200; 
        
        result_pic(result_pic<result_threshold) = 0;
        result_pic(result_pic>=result_threshold) = 1;
        result_pic = logical(result_pic);
        result_pic = imdilate(result_pic,se);
        
        
        gt_rec=regionprops(gt_pic,'Boundingbox');
        res_rec=regionprops(result_pic,'Boundingbox');
        
        if(size(res_rec,1)==0)
            Dr=Dr+0;
            Fa=Fa+0;
            continue;
        end

        is_visited = zeros(size(res_rec,1),1);

        for gt_order = 1:size(gt_rec,1)
            for res_order = 1:size(res_rec,1)
                if(is_visited(res_order)==0)
                   IoU=calc_iou(gt_rec(gt_order).BoundingBox,...
                                res_rec(res_order).BoundingBox);
                   if(IoU>IoU_threshold)
                       is_visited(res_order)=1;
                       break;
                   end
                end
            end
        end
        
        Dr=Dr+sum(is_visited)/size(gt_rec,1);
        Fa=Fa+(size(res_rec,1)-sum(is_visited));
        clear gt_rec;
        clear res_rec;
    end
    
    Dr=Dr/(endframe(i)-startframe(i)+1);
    Fa=Fa/(endframe(i)-startframe(i)+1);
    Dr_store(i)=Dr;
    Fa_store(i)=Fa;
    
end