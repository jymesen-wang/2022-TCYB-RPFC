clear;
addpath('Funcs');
%% The in/output directories
CurrentFolder = pwd;
DATASET = ['\Airplanes'];                    % or ['\Airplanes']; or ['\Drones'];
IN = [CurrentFolder DATASET '\input\'];      % Path of input
OUT = [CurrentFolder DATASET '\out\'];       % Path of output
SUFFIX='.jpg';                               % The format of picture
if ~exist(OUT, 'dir')
    mkdir(OUT);
end

%% The parameters of feature set 
N_RECT_MIN = 2; 
N_RECT_MAX = 8; 
FTR_REPEAT = 5; 
BLOCK_WIDTH = 4;
BLOCK_HEIGHT = 4;
SHOULD_REFORM = 0;
feature_mask = form_feature_mask(N_RECT_MIN,N_RECT_MAX,FTR_REPEAT,BLOCK_WIDTH,BLOCK_HEIGHT,SHOULD_REFORM);

%% The parameters of procedure
INTERVAL = 1;     % step_x, step_y
MIN_DIST = 0.005; % epsilon ��
Colthreshold=10;  % tau     ��

%% The index of frames to be processed
startframe=1;
deltaframe=2;
endframe=100;

%% The initialization of the algorithm
former_frame = imread([IN sprintf('%06d', startframe) SUFFIX]);
former_frame_gray = rgb2gray(former_frame);

[FRAME_HEIGHT,FRAME_WIDTH] = size(former_frame_gray);
[BLOCK_X,BLOCK_Y,bxr,bxc,byr,byc] = form_block_position(INTERVAL,FRAME_WIDTH,BLOCK_WIDTH,FRAME_HEIGHT,BLOCK_HEIGHT);
former_features = calculate_block_features(BLOCK_X,BLOCK_Y,BLOCK_WIDTH,BLOCK_HEIGHT,former_frame_gray,feature_mask);

curr_frame=[];
%% Main Loop
for i=startframe+deltaframe:deltaframe:endframe
    curr_framefornext=curr_frame;

    % Read a new frame
    curr_frame = imread([IN sprintf('%06d', i) SUFFIX]);
    curr_frame_gray = rgb2gray(curr_frame);
    
    % Calculate each block feature
    curr_features = calculate_block_features(BLOCK_X,BLOCK_Y,BLOCK_WIDTH,BLOCK_HEIGHT,curr_frame_gray,feature_mask);

    % Initialize the moving direction vector (mdv)
    % If INTERVAL = 2 blocksize = 4*4 level = 2, movedirection=13 equals to
    % be static
    % If INTERVAL = 1 blocksize = 4*4 level = 4, movedirection=29 equals to
    % be static
    static = 29;
    movedirection=static*ones(length(BLOCK_X),1);
    
    % Compare block with its neighbor blocks
    parfor j=1:length(BLOCK_X)
        if pdist([curr_features(j,:);former_features(j,:)], 'cosine') > MIN_DIST
            
            % The indexes of neighbor blocks
            neighborindexlist=get_neighbor(j,bxr,bxc,4);
            
            if(isempty(neighborindexlist)==1)
                movedirection(j)=static;
                continue;
            end
            lnei=length(neighborindexlist);
            temp=zeros(lnei,1);
            for k=1:lnei
                temp(k)=pdist([curr_features(j,:);former_features(neighborindexlist(k),:)], 'cosine');
            end
            [minvalue,minindex]=min(temp);
            
            if minvalue < MIN_DIST
                movedirection(j)=minindex;
            else
                movedirection(j)=static;
            end
        else
            movedirection(j)=static;
        end
    end
    
    % Eliminating the background movement by histogram
    maxmove=max(movedirection);
    histb=1:maxmove;
    c=histc(movedirection,histb);
    [val,ind]=sort(c,'descend');
    
    center=zeros(1,2); % Store the center of regions
    pointercent=1;     % The counting number of centers
    flag=0;            % Indicate that whether there are some regions changed 
    for j=1:length(movedirection)
        if  movedirection(j)~=histb(ind(1)) && movedirection(j)~=histb(ind(2)) && movedirection(j)~=histb(ind(3))%mod(movedirection(j),5)<=3 && mod(movedirection(j),5)>0
            center(pointercent,:)=[BLOCK_Y(j),BLOCK_X(j)];
            pointercent=pointercent+1;
            flag=1;
            curr_frame_gray(BLOCK_Y(j):BLOCK_Y(j)+BLOCK_HEIGHT-1, BLOCK_X(j):BLOCK_X(j)+BLOCK_WIDTH-1) = ones(BLOCK_HEIGHT, BLOCK_WIDTH) * 255;
        end
    end
    %The illustration after eliminating background movements.
    %figure(3),imshow(curr_frame_gray);
    
    
    % Form the regions and region comparison
    curr_frame_lab=rgb2lab(curr_frame);
    curr_result_bw=zeros(size(curr_frame_gray));
    
    if (flag==1)
        % The color feature of the centers of blocks
        Colormap=get_color_feature(curr_frame_lab,center,BLOCK_HEIGHT,BLOCK_WIDTH);
        
        % Form the regions
        pixelList=form_region(curr_frame_lab,center,Colormap,BLOCK_HEIGHT,BLOCK_WIDTH);

        if isempty(curr_framefornext)==0
            formermeanRgbCol = get_mean_color(curr_framefornext,pixelList);
            newmeanRgbCol = get_mean_color(curr_frame, pixelList);
        else
            formermeanRgbCol = get_mean_color(former_frame,pixelList);
            newmeanRgbCol = get_mean_color(curr_frame, pixelList);
        end
        for j=1:length(pixelList)
            % Same region comparison
            temp=sum((formermeanRgbCol(j,:)-newmeanRgbCol(j,:)).^2,2);
            if temp<Colthreshold
                pixelList{j}=[];
            end
        end
        
        % Form the final result
        pixelList(cellfun(@isempty,pixelList))=[];
        pixelListlength=length(pixelList);
        for j=1:pixelListlength
            row=mod(pixelList{j},FRAME_HEIGHT);
            row=row+(row==0)*FRAME_HEIGHT;
            col=(pixelList{j}-row)/FRAME_HEIGHT+1;
            for kk=1:length(row)
                curr_result_bw(row(kk),col(kk))=1;
            end
        end
    end
    % The Final Result in Binary Color Format
    figure(2),imshow(curr_result_bw);
    
    % Write the result
    %OUTname=strcat(OUT,num2str(i,'%06d'));
    %imwrite(curr_result_bw,[OUTname,SUFFIX]);
    
    % Store the current features
    former_features=curr_features;
end