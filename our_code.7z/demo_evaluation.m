clc;clear all;close all;
addpath('Funcs');
CurrentFolder = 'D:\document\�����µ���\my_code\0805\output\smallobject\'; %pwd;
for i =9:12
    DATASET = {'output_highway','output_PET','output_office','output_peopleInShade','output_O_CL_01','output_O_SN_01','output_I_OC_01','output_O_RA_02','output_four','output_two','output_UAV','output_airplane'};
    groundtruth = {'highway','PETS2006','office','peopleInShade','O_CL_01','O_SN_01','I_OC_01','O_RA_02','Aircrafts_sequence','Airplanes_sequence','Drones_sequence','airplane'};
    result_name = {'M4-*.jpg','M4-*.jpg','M4-*.jpg','M4-*.jpg','M4-*.jpg','M4-*.jpg','M4-*.jpg','M4-*.jpg','*.jpg','*.jpg','*.jpg','*.jpg'};
    truth_name = {'*.png','*.png','*.png','*.png','*.jpg','*.jpg','*.jpg','*.jpg','*.jpg','*.jpg','*.jpg','*.png',};
    RESULT = [CurrentFolder DATASET{i} '\�޴���\'];
    GTfolder = 'D:\document\���ݼ�\Dataset\';%'D:\document\���ݼ�\cdnet2014\';
    % GT = ['D:\document\���ݼ�\cdnet2014\highway\groundtruth\'];
     GT = [GTfolder groundtruth{i} '\GT\'];
    startframe=[670;890;655;600;145;321;100;255;20;228;201;100];
    inter = [469;0;0;0;0;0;0;0;0;0;-200;0];
    endframe=[770;1000;755;800;215;421;150;304;50;278;401;300];
    
    [Pre, Recall, acc, AUC, TPR, FPR] = ...
        evaluate_function(RESULT, result_name{i}, GT, truth_name{i},startframe(i),inter(i),endframe(i));
    % save([CurrentFolder DATASET{i} '_result.mat'],'Pre','Recall','AUC','acc', 'TPR', 'FPR');

    figure(1);set(gcf,'color','white'); xlabel('Recall'); ylabel('Precision');hold on;
    grid on;set(gca,'XTick',0:0.05:1);set(gca,'YTick',0:0.05:1.00);
    plot(Recall,Pre,'r--'); 
    % saveas(gca,[CurrentFolder DATASET{i} '_PR.fig']);
    % figure(2);set(gcf,'color','white'); xlabel('FPR'); ylabel('TPR');hold on;
    % grid on;axis equal;set(gca,'XTick',0:0.05:1);set(gca,'YTick',0:0.05:1.05);
    % plot(FPR,TPR,'b--'); 
    figure(2);set(gcf,'color','white'); xlabel('FPR'); ylabel('TPR');hold on;
    grid on;set(gca,'XTick',0:0.05:1);set(gca,'YTick',0:0.05:1.00);
    plot(FPR,TPR,'r--'); 
%     AUC = 0;
%     [sort_fpr, recall_index] = sort(FPR);
%     for j = 1:length(FPR)-1
%         AUC = AUC+(sort_fpr(j+1)-sort_fpr(j))*(Recall(recall_index(j+1))+Recall(recall_index(j)))*0.5;
%     end
    
    save([CurrentFolder '\evalution\' DATASET{i}, '.mat'],'Pre', 'Recall', 'acc', 'TPR', 'FPR','AUC');
    saveas(figure(1),[CurrentFolder '\evalution\' DATASET{i},'_PR.fig']);
    saveas(figure(2),[CurrentFolder '\evalution\' DATASET{i},'_AUC.fig']);
end