function [precision, recall, acc, AUC,TPR, FPR] = evaluate_function(result_path, result_name, truth_path, truth_name,startframe,inter,endframe)
    dir_result = dir([result_path result_name]);
    dir_truth = dir([truth_path truth_name]);
    color_num =256;
    precision = zeros(color_num,1);
    recall = zeros(color_num,1);
    fpr = zeros(color_num,1);
    acc = zeros(color_num,1);
    TPR = zeros(color_num,1);
    FPR = zeros(color_num,1);

    for i = startframe : endframe

        truth_name = dir_truth(i).name;
        truth_pic = (imread([truth_path truth_name]));
        if size(truth_pic,3) == 3
            truth_pic = rgb2gray(truth_pic);
        end
        
        result_name = dir_result(i-inter).name;
        result_pic = imread([result_path result_name]);
        if size(result_pic,3) == 3
            result_pic = rgb2gray(result_pic);
        end

        truth_pic = im2double(truth_pic);
        tmp = 0.5*max(truth_pic(:));
        truth_pic(truth_pic>=tmp) = 255;
        truth_pic(truth_pic<tmp) = 0;

        truth_pic = double(truth_pic);
        result_pic = double(result_pic);
        groundtruth = sum(truth_pic(:));
        truth_pic = reshape(uint8(truth_pic),1,numel(truth_pic));
        
        for thr = 1 : color_num  
            result_pic_after_thr = zeros(size(result_pic));
            result_pic_after_thr(result_pic>=(thr-1)) = 255;

            res = sum(result_pic_after_thr(:));
            result_pic_after_thr = reshape(uint8(result_pic_after_thr),1,numel(result_pic_after_thr));
            
            resMM =  bitand(result_pic_after_thr,truth_pic);
            common = sum(resMM(:));
            precision(thr) = precision(thr) + common/(res + 1e-8);
            recall(thr) = recall(thr) + common/(groundtruth + 1e-8);

            % cal acc
            xorM = bitxor(result_pic_after_thr,truth_pic);
            count = sum(xorM)/255;
            [w,h] = size(xorM);
            acc(thr) = acc(thr) + (1-count/(w*h));

            % ROC : x(TPR)  y(FPR)
            TPR(thr) = recall(thr);
            FPR(thr) = FPR(thr) + sum(bitand(result_pic_after_thr==255, truth_pic==0)) / sum(truth_pic==0);
        end

    end
    
    intframe=endframe-startframe+1;
    precision = precision./intframe;
    recall = recall./intframe;
    acc = acc./intframe;
    TPR = TPR./intframe;
    FPR = FPR./intframe;
    AUC = 0;
    [sort_fpr, recall_index] = sort(FPR);
    for j = 1:length(fpr)-1
        AUC = AUC+(sort_fpr(j+1)-sort_fpr(j))*(recall(recall_index(j+1))+recall(recall_index(j)))*0.5;
    end
end