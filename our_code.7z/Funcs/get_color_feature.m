function  Colormap = get_color_feature(srcImg,centerpoints,HEIGHT,WIDTH)
    % INPUT:
    % srcImg % The 3 channel color image
    % centerpoints % The upleft points of all the potiential regions
    % HEIGHT % Block height
    % WIDTH % Block width
    % OUTPUT:
    % Colormap % The color features of each potiential regions
    
    cnt=size(centerpoints,1);
    Colormap=zeros(cnt,3);
    m=1;
    for m=1:cnt
        i=centerpoints(m,1);
        j=centerpoints(m,2);
        
        %Extracting the middle part(2*2) of a block as a center
        cube=srcImg(i+1:i+HEIGHT-2,j+1:j+WIDTH-2,:);
        
        Lmean=sum(sum(cube(:,:,1)))/(HEIGHT*WIDTH);
        amean=sum(sum(cube(:,:,2)))/(HEIGHT*WIDTH);
        bmean=sum(sum(cube(:,:,3)))/(HEIGHT*WIDTH);
        Colormap(m,:)=[Lmean, amean, bmean];
    end
end