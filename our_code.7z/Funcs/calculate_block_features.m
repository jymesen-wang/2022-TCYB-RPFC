function image_feature = calculate_block_features(BLOCK_X,BLOCK_Y,BLOCK_WIDTH,BLOCK_HEIGHT,frame_gray,feature_mask)
    % INPUT:
    % BLOCK_X,BLOCK_Y % The positions of blocks in x/y directions
    % BLOCK_WIDTH,BLOCK_HEIGHT % The width and height of a block
    % frame_gray % gray frame
    % feature_mask % The feature set for calculating the features
    % OUTPUT:
    % image_feature % features of blocks
    
    image_feature = [];
    parfor j=1:length(BLOCK_X)
        block = frame_gray(BLOCK_Y(j):BLOCK_Y(j)+BLOCK_HEIGHT-1, BLOCK_X(j):BLOCK_X(j)+BLOCK_WIDTH-1);
        image_feature(j,:) = calculate_feature_vector(block, feature_mask);
    end
end