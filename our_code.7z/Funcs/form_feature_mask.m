function feature_mask = form_feature_mask(N_RECT_MIN,N_RECT_MAX,FTR_REPEAT,BLOCK_WIDTH,BLOCK_HEIGHT,SHOULD_REFORM)
    % INPUT:
    % N_RECT_MIN % Minimum number of rectangles in one Haar feature
    % N_RECT_MAX % Maximum number of rectangles in one Haar feature
    % FTR_REPEAT % The number of Haar feature in feature set
    % BLOCK_WIDTH % The width of a block
    % BLOCK_HEIGHT % The height of a block
    % SHOULD_REFORM % Whether using the existed feature set or not
    % OUTPUT:
    % feature_mask % Feature set
    
    featur_mask=[];
    if(SHOULD_REFORM==1)
        for i = 1:FTR_REPEAT
             % number of rectangles for i-th feature
             n_rect = randi([N_RECT_MIN, N_RECT_MAX]);
             for j=1:n_rect
                 feature_mask(i, j, 1) = randi([1, BLOCK_WIDTH-1]); % x
                 feature_mask(i, j, 2) = randi([1, BLOCK_HEIGHT-1]); % y
                 feature_mask(i, j, 3) = randi([1, BLOCK_WIDTH-feature_mask(i, j, 1)]); % width
                 feature_mask(i, j, 4) = randi([1, BLOCK_HEIGHT-feature_mask(i, j, 2)]); % height
                 feature_mask(i, j, 5) = sign(rand-0.5) / sqrt(n_rect); % weight
             end
        end
        
    else
        load('feature_mask.mat');
    end
    
end