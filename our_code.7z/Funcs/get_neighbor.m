function neighborindexlist=get_neighbor(currentindex,row,col,level)
    % INPUT:
    % currentindex % The index of current block
    % row % The total row number of blocks
    % col % The total column number of blocks
    % level % The size of search regions. level=1:3*3-1  level=2:5*5-1, such
    % as:
    %                                1  2  3  4  5
    %           1 2 3                6  7  8  9 10
    % level = 1:4 X 5    level = 2: 11 12  X 13 14
    %           6 7 8               15 16 17 18 19
    %                               20 21 22 23 24
    % OUTPUT:
    % neighborindexlist % The index of the neighbor blocks of current one
    
    colnew=mod(currentindex,col);
    if colnew==0
        colnew=col;
    end
    rownew=(currentindex-colnew)/col;
    if rownew==0
        rownew=rownew+1;
    end
    neighborindexlist=[];
    if (rownew<=level||rownew>=row-level||colnew<=level||colnew>=col-level)

    else
        temp=[];
        for i=-level:level
            temp=[temp,currentindex+col*i-level:currentindex+col*i+level];
        end
        neighborindexlist=temp;
    end
end