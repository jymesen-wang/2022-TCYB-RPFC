function [BLOCK_X,BLOCK_Y,bxr,bxc,byr,byc] = form_block_position(INTERVAL,FRAME_WIDTH,BLOCK_WIDTH,FRAME_HEIGHT,BLOCK_HEIGHT)
    % INPUT:
    % INTERVAL % The parameters of step_x and step_y, set to equal
    % FRAME_WIDTH % The width of an image
    % BLOCK_WIDTH % The width of a block
    % FRAME_HEIGHT % The height of an image
    % BLOCK_HEIGHT % The height of a block
    % OUTPUT:
    % BLOCK_X % The position x of blocks
    % BLOCK_Y % The position y of blocks
    
    BLOCK_X = 1:INTERVAL:FRAME_WIDTH-BLOCK_WIDTH;
    BLOCK_Y = 1:INTERVAL:FRAME_HEIGHT-BLOCK_HEIGHT;
    [BLOCK_X, BLOCK_Y] = ndgrid(BLOCK_X, BLOCK_Y);

    [bxr,bxc] = size(BLOCK_X);
    [byr,byc] = size(BLOCK_Y);
    
    BLOCK_X = BLOCK_X(:);
    BLOCK_Y = BLOCK_Y(:);
end