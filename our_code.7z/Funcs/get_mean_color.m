function meanCol = get_mean_color(image, pixelList)
    % INPUT:
    % image % image
    % pixelList % The index list of pixels which belong to a center
    % OUTPUT:
    % meanCol % The mean color on each channel
    
    [h, w, chn] = size(image);
    tmpImg=reshape(image, h*w, chn);

    pixNum = length(pixelList);
    meanCol=zeros(pixNum, chn);
    for i=1:pixNum
        meanCol(i, :)=mean(tmpImg(pixelList{i},:), 1);
    end
    %for gray images
    if chn ==1 
        meanCol = repmat(meanCol, [1, 3]);
    end
end