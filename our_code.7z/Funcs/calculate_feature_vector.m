function  feature_vec  = calculate_feature_vector( block , feature_mask  )
    % INPUT:
    % block % block
    % feature_mask % The formed feature mask for calculating the vetors
    % OUTPUT:
    % feature_vec
    
    for i=1:length(feature_mask(:, 1, 1))
        value = 0;
        for j=1:length(feature_mask(i, :, 1))
            rect = feature_mask(i,j,:);
            if rect(1) == 0
                break;
            end
            value = value + rect(5) * sum(sum(block(rect(2):rect(2)+rect(4)-1, rect(1):rect(1)+rect(3)-1)));
        end
        feature_vec(i) = value;
    end
end

