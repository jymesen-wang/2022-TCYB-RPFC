function IoU = calc_iou(box1,box2)
    x1_max = box1(1)+box1(3);
    x1_min = box1(1);
    y1_max = box1(2)+box1(4);
    y1_min = box1(2);
    
    x2_max = box2(1)+box2(3);
    x2_min = box2(1);
    y2_max = box2(2)+box2(4);
    y2_min = box2(2);
    
    inter_x_max = min(x1_max,x2_max);
    inter_x_min = max(x1_min,x2_min);
    
    inter_y_max = min(y1_max,y2_max);
    inter_y_min = max(y1_min,y2_min);
    
    inter_w = inter_x_max - inter_x_min;
    inter_h = inter_y_max - inter_y_min;
    
    if(inter_w<=0 || inter_h <=0)
        inter=0;
    else
        inter=inter_w*inter_h;
    end
    union = box1(3)*box1(4)+box2(3)*box2(4)-inter;
    
    IoU=inter/union;
end